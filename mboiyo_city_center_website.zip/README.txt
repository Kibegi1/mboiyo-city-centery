MBOIYO CITY CENTER WEBSITE

How to open:
1. Extract the ZIP file.
2. Open index.html in Firefox or Chromium.
3. Replace sample product names, prices, and descriptions.
4. Replace each "Product Photo" box with real product images later.

Business details:
- Shop: MBOIYO CITY CENTER
- Category: Men's clothes
- Location: Dodoma, Tanzania
- WhatsApp: 0782775318
